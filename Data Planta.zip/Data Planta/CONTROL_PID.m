%% ==========================================
% CONTROLADOR PID
% PLANTA IDENTIFICADA POR SYSTEM IDENTIFICATION
% ===========================================

clc
clear
close all

%% 1. FUNCION DE TRANSFERENCIA IDENTIFICADA

num = [2.123 4.386];
den = [1 5.534 7.526];

Gp = tf(num,den);

disp('Funcion de transferencia de la planta')
Gp

%% 2. PARAMETROS DEL PID

Kp = 10;
Ki = 15;
Kd = 0.02;   % Valor inicial para estudiar efecto derivativo

Cpid = pid(Kp,Ki,Kd);

disp('Controlador PID')
Cpid

%% 3. SISTEMA EN LAZO CERRADO

Tpid = feedback(Cpid*Gp,1);

%% 4. RESPUESTA AL ESCALON

figure
step(Tpid)
grid on

title('Respuesta al escalon con controlador PID')
xlabel('Tiempo (s)')
ylabel('Salida')

%% 5. INFORMACION TEMPORAL

infoPID = stepinfo(Tpid);

disp('Informacion temporal del PID')
disp(infoPID)

%% 6. ERROR EN ESTADO ESTACIONARIO

valor_final = dcgain(Tpid);

error_estacionario = abs(1 - valor_final);

fprintf('\n');
fprintf('Valor final = %.4f\n',valor_final);
fprintf('Error estacionario = %.6f\n',error_estacionario);

%% 7. POLOS DEL SISTEMA CONTROLADO

polosPID = pole(Tpid);

disp('Polos del sistema controlado')
disp(polosPID)

%% 8. MAPA DE POLOS Y CEROS

figure
pzmap(Tpid)
grid on

title('Mapa de polos y ceros del sistema con PID')

%% 9. RESPUESTA AL IMPULSO

figure
impulse(Tpid)
grid on

title('Respuesta al impulso con PID')

%% 10. COMPARACION PI VS PID

Cpi = pid(1.87,16.1);

Tpi = feedback(Cpi*Gp,1);

figure

step(Tpi)
hold on
step(Tpid)

grid on

legend('PI','PID')
title('Comparacion PI vs PID')

%% 11. RESUMEN FINAL

fprintf('\n');
fprintf('====================================\n');
fprintf('RESULTADOS CONTROLADOR PID\n');
fprintf('====================================\n');

fprintf('Kp = %.4f\n',Kp);
fprintf('Ki = %.4f\n',Ki);
fprintf('Kd = %.4f\n',Kd);

fprintf('\nRise Time      = %.4f s\n',infoPID.RiseTime);
fprintf('Settling Time  = %.4f s\n',infoPID.SettlingTime);
fprintf('Overshoot      = %.4f %%\n',infoPID.Overshoot);
fprintf('Valor Final    = %.4f\n',valor_final);
fprintf('Error Estacionario = %.6f\n',error_estacionario);