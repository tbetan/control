%% DATOS

t = IDENTIFICACION(:,1);
y = IDENTIFICACION(:,2);

% Eliminar segundo cero
t(2) = [];
y(2) = [];

%% Valor final

yf = y(end);

%% Ganancia (escalón de 8 V)

K = (yf-y(1))/8;

%% Niveles 35.3% y 85.3%

y35 = 0.353*yf;
y85 = 0.853*yf;

%% Encontrar tiempos correspondientes

i35 = find(y>=y35,1);
i85 = find(y>=y85,1);

t35 = t(i35);
t85 = t(i85);

%% Parámetros del método Sundaresan y Krishnaswamy

T = 0.67*(t85-t35);

L = 1.3*t35 - 0.29*t85;

%% Mostrar resultados

fprintf('K = %.6f\n',K)
fprintf('L = %.6f s\n',L)
fprintf('T = %.6f s\n',T)

%% Función de transferencia

s = tf('s');

G_SK = K*exp(-L*s)/(T*s+1)