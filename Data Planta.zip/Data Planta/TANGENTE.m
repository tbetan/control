%% DATOS

t = IDENTIFICACION(:,1);
y = IDENTIFICACION(:,2);

% Eliminar segundo cero
t(2) = [];
y(2) = [];

% Suavizar
y_s = smoothdata(y,'movmean',30);

% Derivada
dy = gradient(y_s,t);

% Buscar máximo de pendiente entre el 10% y el 90%
yf = y(end);

ind = find(y_s > 0.1*yf & y_s < 0.9*yf);

[pend_max,pos] = max(dy(ind));

indice = ind(pos);

t_inf = t(indice);
y_inf = y_s(indice);

% Recta tangente
y_tan = pend_max*(t-t_inf)+y_inf;

% Parámetros
K = (y(end)-y(1))/8;

L = t_inf - y_inf/pend_max;

t_LT = (yf-y_inf)/pend_max + t_inf;

T = t_LT - L;

fprintf('K = %.6f\n',K)
fprintf('L = %.6f s\n',L)
fprintf('T = %.6f s\n',T)

%% Gráfica

figure
plot(t,y,'b','LineWidth',2)
hold on
plot(t,y_s,'g','LineWidth',2)
plot(t,y_tan,'r--','LineWidth',2)

xline(L,'k--','LineWidth',1.5)
xline(L+T,'m--','LineWidth',1.5)
yline(yf,'c--','LineWidth',1.5)

plot(t_inf,y_inf,'ko','MarkerFaceColor','k')

grid on
legend('Datos originales','Datos suavizados','Recta tangente','L','L+T','Valor final','Punto de inflexión')

xlabel('Tiempo (s)')
ylabel('Voltaje (V)')
title('Método de la Recta Tangente')