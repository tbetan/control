%% DATOS EXPERIMENTALES
y_real = out.DATA_ORIGINAL;

%% PORCENTAJE DE AJUSTE

FIT_ALFARO = 100*(1 - norm(y_real-out.ALFARO)/norm(y_real-mean(y_real)));
FIT_BROIDA = 100*(1 - norm(y_real-out.BROIDA)/norm(y_real-mean(y_real)));
FIT_CHAEN = 100*(1 - norm(y_real-out.CHAEN)/norm(y_real-mean(y_real)));
FIT_HOETAL = 100*(1 - norm(y_real-out.HOETAL)/norm(y_real-mean(y_real)));
FIT_SMITH = 100*(1 - norm(y_real-out.SMITH)/norm(y_real-mean(y_real)));
FIT_VITECKOVA = 100*(1 - norm(y_real-out.VITECKOVA)/norm(y_real-mean(y_real)));
FIT_MINIMOS = 100*(1 - norm(y_real-out.MINIMOSCUAD)/norm(y_real-mean(y_real)));
FIT_TANGENTE = 100*(1 - norm(y_real-out.TANGENTE)/norm(y_real-mean(y_real)));
FIT_SISTEMID = 100*(1 - norm(y_real-out.SISTEMID)/norm(y_real-mean(y_real)));
FIT_SK = 100*(1 - norm(y_real-out.SK)/norm(y_real-mean(y_real)));

%% TABLA DE RESULTADOS

Metodo = {
'Alfaro';
'Broida';
'Chae y Yan';
'Ho et al';
'Smith';
'Viteckova';
'Minimos Cuadrados';
'Recta Tangente';
'System Identification';
'Sundaresan-Krishnaswamy'};

Fit_Porcentaje = [
FIT_ALFARO;
FIT_BROIDA;
FIT_CHAEN;
FIT_HOETAL;
FIT_SMITH;
FIT_VITECKOVA;
FIT_MINIMOS;
FIT_TANGENTE;
FIT_SISTEMID;
FIT_SK];

Resultados = table(Metodo,Fit_Porcentaje);

%% ORDENAR DE MAYOR A MENOR

Resultados = sortrows(Resultados,'Fit_Porcentaje','descend');

disp(Resultados)