classdef HMI_MotorGenerador < matlab.apps.AppBase

% ================================================================
%  HMI_MotorGenerador.m
%  Motor DC (primario) + Motor DC (generador)
%  Modos: CONTROL (PID) e IDENTIFICACIÓN (PWM manual)
%  G(s) = (2.123s + 4.386) / (s^2 + 5.534s + 7.526)
% ================================================================

    properties (Access = public)
        UIFigure            matlab.ui.Figure

        % Paneles
        PnlConexion         matlab.ui.container.Panel
        PnlReferencia       matlab.ui.container.Panel
        PnlControlador      matlab.ui.container.Panel
        PnlGanancias        matlab.ui.container.Panel
        PnlIndicadores      matlab.ui.container.Panel
        PnlIdent            matlab.ui.container.Panel

        % Conexión
        EditCOM             matlab.ui.control.EditField
        BtnConectar         matlab.ui.control.Button
        BtnDesconectar      matlab.ui.control.Button
        LblEstado           matlab.ui.control.Label

        % Modo
        BtnModoCtrl         matlab.ui.control.Button
        BtnModoIdent        matlab.ui.control.Button

        % Referencia
        SliderRef           matlab.ui.control.Slider
        EditRef             matlab.ui.control.NumericEditField

        % Controlador
        BtnGrpCtrl          matlab.ui.container.ButtonGroup
        RBtnP               matlab.ui.control.RadioButton
        RBtnPI              matlab.ui.control.RadioButton
        RBtnPID             matlab.ui.control.RadioButton

        % Ganancias
        EditKp              matlab.ui.control.NumericEditField
        EditKi              matlab.ui.control.NumericEditField
        EditKd              matlab.ui.control.NumericEditField
        BtnAplicar          matlab.ui.control.Button

        % Botones control
        BtnIniciar          matlab.ui.control.Button
        BtnDetener          matlab.ui.control.Button
        BtnModoOscuro       matlab.ui.control.Button

        % Indicadores
        NumVoltaje          matlab.ui.control.NumericEditField
        NumError            matlab.ui.control.NumericEditField
        NumPWM              matlab.ui.control.NumericEditField
        NumTiempo           matlab.ui.control.NumericEditField

        % Identificación
        EditPwmIdent        matlab.ui.control.NumericEditField
        BtnAplicarPwm       matlab.ui.control.Button
        BtnEscalonUp        matlab.ui.control.Button
        BtnEscalonDn        matlab.ui.control.Button
        LblIdentInfo        matlab.ui.control.Label
        BtnCompararModelos  matlab.ui.control.Button

        % Gráficas
        AxesVolt            matlab.ui.control.UIAxes
        AxesPWM             matlab.ui.control.UIAxes

        % Exportar
        BtnExcel            matlab.ui.control.Button
        BtnCSV              matlab.ui.control.Button
        BtnLimpiar          matlab.ui.control.Button
    end

    properties (Access = private)
        SerialObj   = []
        CtrlTimer   = []

        tHist   = [];  vHist   = [];
        pwmHist = [];  errHist = [];  refHist = []

        tIni    = 0
        Kp = 5;  Ki = 15;  Kd = 0.1
        TipoCtrl     = 'PID'
        IntegralAcum = 0
        ErrorPrev    = 0
        Ts       = 0.20
        Ref      = 0
        VoltPrev = 0
        ModoOscuro = true
        ModoOp   = 'control'
        PwmIdent = 150
        Corriendo = false
    end

    methods (Access = private)

        function buildUI(app)
            fig = app.UIFigure;
            fig.Name     = 'HMI Motor–Generador  |  Control en Tiempo Real';
            fig.Position = [40 40 1400 820];
            fig.Resize   = 'on';
            fig.Color    = [0.00 0.00 0.00];

            LW = 300;   % ancho panel izquierdo
            X  = 10;    % margen izquierdo
            GX = LW+15; % inicio gráficas
            GW = 1400-LW-25; % ancho gráficas

            % ════════════════════════════════════════════════
            %  BARRA SUPERIOR
            % ════════════════════════════════════════════════
            % Título centrado en zona gráficas
            uilabel(fig,'Text','HMI  |  MOTOR–GENERADOR  |  Control en Tiempo Real', ...
                'Position',[GX 788 GW 26], ...
                'FontSize',15,'FontWeight','bold', ...
                'FontColor',[0.00 0.65 1.00], ...
                'HorizontalAlignment','center','Tag','titulo');

            % Botón modo oscuro/claro
            app.BtnModoOscuro = uibutton(fig,'push','Text','☀  Modo Claro', ...
                'Position',[X 790 140 24], ...
                'BackgroundColor',[0.20 0.23 0.30], ...
                'FontColor',[0.88 0.91 0.96],'FontWeight','bold','FontSize',10, ...
                'ButtonPushedFcn',@(~,~) app.toggleModo());

            % Botones exportar
            app.BtnExcel = uibutton(fig,'push','Text','📊 Excel', ...
                'Position',[X 762 90 24], ...
                'BackgroundColor',[0.07 0.42 0.18],'FontColor','white','FontWeight','bold', ...
                'ButtonPushedFcn',@(~,~) app.guardarExcel());
            app.BtnCSV = uibutton(fig,'push','Text','📄 CSV', ...
                'Position',[105 762 85 24], ...
                'BackgroundColor',[0.07 0.28 0.52],'FontColor','white','FontWeight','bold', ...
                'ButtonPushedFcn',@(~,~) app.guardarCSV());
            app.BtnLimpiar = uibutton(fig,'push','Text','🗑 Limpiar', ...
                'Position',[195 762 115 24], ...
                'BackgroundColor',[0.38 0.12 0.08],'FontColor','white','FontWeight','bold', ...
                'ButtonPushedFcn',@(~,~) app.limpiarDatos());

            % ════════════════════════════════════════════════
            %  SELECTOR DE MODO  (barra debajo de exportar)
            % ════════════════════════════════════════════════
            app.BtnModoCtrl = uibutton(fig,'push','Text','⚙  CONTROL', ...
                'Position',[X 730 145 28], ...
                'BackgroundColor',[0.05 0.45 0.75], ...
                'FontColor','white','FontWeight','bold','FontSize',11, ...
                'ButtonPushedFcn',@(~,~) app.setModoControl());
            app.BtnModoIdent = uibutton(fig,'push','Text','📊  IDENTIFICACIÓN', ...
                'Position',[160 730 150 28], ...
                'BackgroundColor',[0.22 0.18 0.08], ...
                'FontColor',[0.75 0.70 0.55],'FontWeight','bold','FontSize',11, ...
                'ButtonPushedFcn',@(~,~) app.setModoIdent());

            % ════════════════════════════════════════════════
            %  PANEL CONEXIÓN  y=630 h=95
            % ════════════════════════════════════════════════
            p = uipanel(fig,'Title','CONEXIÓN SERIAL', ...
                'Position',[X 630 LW 95], ...
                'BackgroundColor',[0.08 0.08 0.08], ...
                'ForegroundColor',[0.00 0.65 1.00], ...
                'FontWeight','bold','FontSize',10,'Tag','panel');
            app.PnlConexion = p;

            uilabel(p,'Text','Puerto COM:', ...
                'Position',[8 62 80 20],'FontColor',[0.75 0.80 0.88], ...
                'BackgroundColor',[0.08 0.08 0.08],'Tag','lbl');
            app.EditCOM = uieditfield(p,'text','Value','COM5', ...
                'Position',[92 62 190 22], ...
                'BackgroundColor',[0.12 0.12 0.12],'FontColor',[0.90 0.93 0.97], ...
                'Tag','edit');
            app.BtnConectar = uibutton(p,'push','Text','▶ CONECTAR', ...
                'Position',[8 36 135 24], ...
                'BackgroundColor',[0.05 0.52 0.22],'FontColor','white','FontWeight','bold', ...
                'ButtonPushedFcn',@(~,~) app.conectar());
            app.BtnDesconectar = uibutton(p,'push','Text','■ DESCONECTAR', ...
                'Position',[148 36 142 24],'Enable','off', ...
                'BackgroundColor',[0.52 0.10 0.10],'FontColor','white','FontWeight','bold', ...
                'ButtonPushedFcn',@(~,~) app.desconectar());
            app.LblEstado = uilabel(p,'Text','● DESCONECTADO', ...
                'Position',[8 8 280 22], ...
                'FontColor',[0.85 0.20 0.20],'FontWeight','bold', ...
                'BackgroundColor',[0.08 0.08 0.08],'Tag','lbl');

            % ════════════════════════════════════════════════
            %  PANEL REFERENCIA  y=530 h=95
            % ════════════════════════════════════════════════
            p = uipanel(fig,'Title','REFERENCIA  (0 – 10 V)', ...
                'Position',[X 530 LW 95], ...
                'BackgroundColor',[0.08 0.08 0.08], ...
                'ForegroundColor',[0.00 0.65 1.00], ...
                'FontWeight','bold','FontSize',10,'Tag','panel');
            app.PnlReferencia = p;

            app.SliderRef = uislider(p,'Limits',[0 10],'Value',0, ...
                'Position',[8 62 278 3], ...
                'ValueChangedFcn',@(s,~) app.sliderCambiado(s));
            uilabel(p,'Text','Ref (V):', ...
                'Position',[8 18 55 20],'FontColor',[0.75 0.80 0.88], ...
                'BackgroundColor',[0.08 0.08 0.08],'Tag','lbl');
            app.EditRef = uieditfield(p,'numeric','Value',0, ...
                'Limits',[0 10],'Position',[68 16 100 24], ...
                'BackgroundColor',[0.12 0.12 0.12],'FontColor',[0.90 0.93 0.97], ...
                'Tag','edit', ...
                'ValueChangedFcn',@(s,~) app.editRefCambiado(s));
            uilabel(p,'Text','V', ...
                'Position',[174 18 20 20],'FontColor',[0.00 0.65 1.00], ...
                'BackgroundColor',[0.08 0.08 0.08],'Tag','lbl');

            % ════════════════════════════════════════════════
            %  PANEL CONTROLADOR  y=435 h=90
            % ════════════════════════════════════════════════
            p = uipanel(fig,'Title','CONTROLADOR', ...
                'Position',[X 435 LW 90], ...
                'BackgroundColor',[0.08 0.08 0.08], ...
                'ForegroundColor',[0.00 0.65 1.00], ...
                'FontWeight','bold','FontSize',10,'Tag','panel');
            app.PnlControlador = p;

            bg = uibuttongroup(p,'Position',[4 28 290 38], ...
                'BackgroundColor',[0.08 0.08 0.08], ...
                'BorderType','none', ...
                'SelectionChangedFcn',@(s,~) app.ctrlCambiado(s));
            app.BtnGrpCtrl = bg;
            app.RBtnP   = uiradiobutton(bg,'Text',' P',  'Position',[5  10 65 20], ...
                'FontColor',[0.88 0.92 0.97]);
            app.RBtnPI  = uiradiobutton(bg,'Text',' PI', 'Position',[95 10 65 20], ...
                'FontColor',[0.88 0.92 0.97]);
            app.RBtnPID = uiradiobutton(bg,'Text',' PID','Position',[185 10 75 20], ...
                'FontColor',[0.88 0.92 0.97]);
            app.RBtnPID.Value = true;

            uilabel(p,'Text','G(s) = (2.123s+4.386) / (s²+5.534s+7.526)', ...
                'Position',[6 6 288 18],'FontSize',8, ...
                'FontColor',[0.45 0.55 0.68],'BackgroundColor',[0.08 0.08 0.08]);

            % ════════════════════════════════════════════════
            %  PANEL GANANCIAS  y=310 h=120
            % ════════════════════════════════════════════════
            p = uipanel(fig,'Title','GANANCIAS  (Tiempo Real)', ...
                'Position',[X 310 LW 120], ...
                'BackgroundColor',[0.08 0.08 0.08], ...
                'ForegroundColor',[0.00 0.65 1.00], ...
                'FontWeight','bold','FontSize',10,'Tag','panel');
            app.PnlGanancias = p;

            ganancia = {'Kp','Ki','Kd'};
            yg = [88 58 28];
            vals = [5 15 0.1];
            flds = {'EditKp','EditKi','EditKd'};
            for k=1:3
                uilabel(p,'Text',[ganancia{k} ' :'], ...
                    'Position',[8 yg(k) 32 20],'FontWeight','bold', ...
                    'FontColor',[0.88 0.92 0.97],'BackgroundColor',[0.08 0.08 0.08]);
                app.(flds{k}) = uieditfield(p,'numeric','Value',vals(k), ...
                    'Position',[44 yg(k) 110 22], ...
                    'BackgroundColor',[0.12 0.12 0.12],'FontColor',[0.90 0.93 0.97]);
            end
            app.BtnAplicar = uibutton(p,'push','Text','✔  APLICAR GANANCIAS', ...
                'Position',[8 4 284 22], ...
                'BackgroundColor',[0.05 0.38 0.70],'FontColor','white','FontWeight','bold', ...
                'ButtonPushedFcn',@(~,~) app.aplicarGanancias());

            % ════════════════════════════════════════════════
            %  BOTONES INICIAR / DETENER  y=268 h=36
            % ════════════════════════════════════════════════
            app.BtnIniciar = uibutton(fig,'push','Text','▶  INICIAR CONTROL', ...
                'Position',[X 268 145 36], ...
                'BackgroundColor',[0.05 0.60 0.25],'FontColor','white', ...
                'FontWeight','bold','FontSize',12, ...
                'ButtonPushedFcn',@(~,~) app.iniciarControl());
            app.BtnDetener = uibutton(fig,'push','Text','■  DETENER', ...
                'Position',[160 268 150 36], ...
                'BackgroundColor',[0.65 0.10 0.10],'FontColor','white', ...
                'FontWeight','bold','FontSize',12, ...
                'ButtonPushedFcn',@(~,~) app.detenerControl());

            % ════════════════════════════════════════════════
            %  PANEL INDICADORES  y=85 h=178
            % ════════════════════════════════════════════════
            p = uipanel(fig,'Title','INDICADORES', ...
                'Position',[X 85 LW 178], ...
                'BackgroundColor',[0.08 0.08 0.08], ...
                'ForegroundColor',[0.00 0.65 1.00], ...
                'FontWeight','bold','FontSize',10,'Tag','panel');
            app.PnlIndicadores = p;

            lbls  = {'Voltaje (V)','Error (V)','PWM (0-255)','Tiempo (s)'};
            clrs  = {[0.00 0.72 1.00],[1.00 0.75 0.00],[1.00 0.55 0.10],[0.65 0.72 0.82]};
            yy    = [136 100 64 28];
            flds2 = {'NumVoltaje','NumError','NumPWM','NumTiempo'};
            for k=1:4
                uilabel(p,'Text',lbls{k}, ...
                    'Position',[8 yy(k)+2 108 18], ...
                    'FontColor',[0.60 0.68 0.80],'FontSize',10, ...
                    'BackgroundColor',[0.08 0.08 0.08]);
                ef = uieditfield(p,'numeric','Value',0,'Editable','off', ...
                    'Position',[120 yy(k) 168 26], ...
                    'BackgroundColor',[0.04 0.04 0.04], ...
                    'FontColor',clrs{k},'FontSize',14,'FontWeight','bold');
                app.(flds2{k}) = ef;
            end

            % ════════════════════════════════════════════════
            %  PANEL IDENTIFICACIÓN  y=85 h=178  (oculto)
            % ════════════════════════════════════════════════
            p = uipanel(fig,'Title','PWM MANUAL  –  IDENTIFICACIÓN', ...
                'Position',[X 85 LW 210], ...
                'BackgroundColor',[0.08 0.08 0.08], ...
                'ForegroundColor',[0.85 0.65 0.10], ...
                'FontWeight','bold','FontSize',10,'Visible','off','Tag','panel');
            app.PnlIdent = p;

            uilabel(p,'Text','PWM fijo (0-255):', ...
                'Position',[8 172 110 20],'FontColor',[0.75 0.80 0.88], ...
                'BackgroundColor',[0.08 0.08 0.08]);
            app.EditPwmIdent = uieditfield(p,'numeric','Value',150, ...
                'Limits',[0 255],'Position',[122 170 100 24], ...
                'BackgroundColor',[0.12 0.12 0.12],'FontColor',[0.90 0.93 0.97]);
            app.BtnAplicarPwm = uibutton(p,'push','Text','▶  APLICAR PWM FIJO', ...
                'Position',[8 140 284 26], ...
                'BackgroundColor',[0.05 0.38 0.65],'FontColor','white','FontWeight','bold', ...
                'ButtonPushedFcn',@(~,~) app.aplicarPwmFijo());
            app.BtnEscalonUp = uibutton(p,'push','Text','▲  Escalón  +50 PWM', ...
                'Position',[8 108 284 26], ...
                'BackgroundColor',[0.05 0.45 0.20],'FontColor','white','FontWeight','bold', ...
                'ButtonPushedFcn',@(~,~) app.aplicarEscalon(50));
            app.BtnEscalonDn = uibutton(p,'push','Text','▼  Escalón  −50 PWM', ...
                'Position',[8 76 284 26], ...
                'BackgroundColor',[0.45 0.12 0.05],'FontColor','white','FontWeight','bold', ...
                'ButtonPushedFcn',@(~,~) app.aplicarEscalon(-50));
            app.BtnCompararModelos = uibutton(p,'push', ...
                'Text','📊  COMPARAR MODELOS DE IDENTIFICACIÓN', ...
                'Position',[8 44 284 28], ...
                'BackgroundColor',[0.45 0.20 0.55],'FontColor','white','FontWeight','bold','FontSize',10, ...
                'ButtonPushedFcn',@(~,~) app.abrirComparacion());
            app.LblIdentInfo = uilabel(p,'Text','Conecte y ajuste el PWM', ...
                'Position',[8 10 284 28], ...
                'FontColor',[0.65 0.70 0.55],'FontSize',10, ...
                'HorizontalAlignment','center', ...
                'BackgroundColor',[0.08 0.08 0.08]);

            % ════════════════════════════════════════════════
            %  BARRA INFERIOR IZQUIERDA  y=8 h=72
            % ════════════════════════════════════════════════
            % Info de la planta
            uilabel(fig,'Text','Planta: Motor DC + Generador  |  Arduino Uno + L298N  |  Ts = 200 ms', ...
                'Position',[X 60 LW 20],'FontSize',8, ...
                'FontColor',[0.38 0.45 0.55], ...
                'HorizontalAlignment','center');
            uilabel(fig,'Text','Fit identificación: 98.42 %  |  p₁=−3.128  p₂=−2.406  z=−2.066', ...
                'Position',[X 42 LW 18],'FontSize',8, ...
                'FontColor',[0.38 0.45 0.55], ...
                'HorizontalAlignment','center');

            % ════════════════════════════════════════════════
            %  GRÁFICA VOLTAJE  y=420 h=365
            % ════════════════════════════════════════════════
            ax1 = uiaxes(fig,'Position',[GX 415 GW 365]);
            app.AxesVolt = ax1;
            ax1.Color       = [0.04 0.04 0.04];
            ax1.XColor      = [0.55 0.62 0.72];
            ax1.YColor      = [0.55 0.62 0.72];
            ax1.GridColor   = [0.18 0.22 0.28];
            ax1.GridAlpha   = 0.6;
            ax1.XGrid = 'on'; ax1.YGrid = 'on';
            ax1.Title.String  = 'Voltaje Medido  vs  Referencia';
            ax1.Title.Color   = [0.00 0.65 1.00];
            ax1.Title.FontSize = 11;
            ax1.XLabel.String = 'Tiempo (s)';
            ax1.XLabel.Color  = [0.55 0.62 0.72];
            ax1.YLabel.String = 'Voltaje (V)';
            ax1.YLabel.Color  = [0.55 0.62 0.72];
            ax1.YLim = [0 12];
            hold(ax1,'on');

            % ════════════════════════════════════════════════
            %  GRÁFICA PWM  y=20 h=385
            % ════════════════════════════════════════════════
            ax2 = uiaxes(fig,'Position',[GX 20 GW 385]);
            app.AxesPWM = ax2;
            ax2.Color       = [0.04 0.04 0.04];
            ax2.XColor      = [0.55 0.62 0.72];
            ax2.YColor      = [0.55 0.62 0.72];
            ax2.GridColor   = [0.18 0.22 0.28];
            ax2.GridAlpha   = 0.6;
            ax2.XGrid = 'on'; ax2.YGrid = 'on';
            ax2.Title.String  = 'PWM Aplicado al Motor Principal';
            ax2.Title.Color   = [0.00 0.65 1.00];
            ax2.Title.FontSize = 11;
            ax2.XLabel.String = 'Tiempo (s)';
            ax2.XLabel.Color  = [0.55 0.62 0.72];
            ax2.YLabel.String = 'PWM (0–255)';
            ax2.YLabel.Color  = [0.55 0.62 0.72];
            ax2.YLim = [0 270];
            hold(ax2,'on');

            app.aplicarModo();
        end

        % ── Modo oscuro/claro ────────────────────────────────────────
        function aplicarModo(app)
            if app.ModoOscuro
                bg   = [0.00 0.00 0.00];   % negro puro
                pbg  = [0.08 0.08 0.08];   % paneles casi negro
                txt  = [0.92 0.94 0.96];
                edbg = [0.12 0.12 0.12];
                axbg = [0.04 0.04 0.04];
                axcl = [0.60 0.65 0.72];
                gcol = [0.18 0.18 0.18];
                btnT = '☀  Modo Claro';
                btnB = [0.15 0.15 0.15];
                btnF = [0.92 0.94 0.96];
            else
                bg   = [0.93 0.94 0.96];
                pbg  = [1.00 1.00 1.00];
                txt  = [0.10 0.12 0.18];
                edbg = [0.88 0.90 0.94];
                axbg = [1.00 1.00 1.00];
                axcl = [0.25 0.28 0.35];
                gcol = [0.78 0.80 0.84];
                btnT = '🌙  Modo Oscuro';
                btnB = [0.78 0.80 0.86];
                btnF = [0.10 0.12 0.18];
            end
            if ~isvalid(app.UIFigure), return; end
            app.UIFigure.Color = bg;
            try
                app.BtnModoOscuro.Text            = btnT;
                app.BtnModoOscuro.BackgroundColor  = btnB;
                app.BtnModoOscuro.FontColor        = btnF;
            catch; end
            kids = findall(app.UIFigure);
            for k=1:numel(kids)
                c=kids(k);
                try tg=c.Tag; catch; tg=''; end
                try
                    switch tg
                        case 'panel'
                            c.BackgroundColor=pbg;
                            c.ForegroundColor=[0.00 0.65 1.00];
                        case 'lbl'
                            c.BackgroundColor=pbg;
                            c.FontColor=txt;
                        case 'edit'
                            c.BackgroundColor=edbg;
                            c.FontColor=txt;
                        case 'titulo'
                            c.FontColor=[0.00 0.65 1.00];
                    end
                catch; end
            end
            for ax=[app.AxesVolt app.AxesPWM]
                try
                    ax.Color=axbg; ax.XColor=axcl; ax.YColor=axcl;
                    ax.GridColor=gcol;
                    ax.Title.Color=[0.00 0.65 1.00];
                    ax.XLabel.Color=axcl; ax.YLabel.Color=axcl;
                catch; end
            end
        end

        function toggleModo(app)
            app.ModoOscuro = ~app.ModoOscuro;
            app.aplicarModo();
        end

        % ── Modo CONTROL ─────────────────────────────────────────────
        function setModoControl(app)
            app.detenerControl();
            app.ModoOp = 'control';
            app.BtnModoCtrl.BackgroundColor  = [0.05 0.45 0.75];
            app.BtnModoCtrl.FontColor        = [1 1 1];
            app.BtnModoIdent.BackgroundColor = [0.22 0.18 0.08];
            app.BtnModoIdent.FontColor       = [0.75 0.70 0.55];
            app.PnlReferencia.Visible  = 'on';
            app.PnlControlador.Visible = 'on';
            app.PnlGanancias.Visible   = 'on';
            app.BtnIniciar.Visible     = 'on';
            app.BtnDetener.Visible     = 'on';
            app.PnlIdent.Visible       = 'off';
            app.PnlIndicadores.Visible = 'on';
            app.AxesVolt.Title.String  = 'Voltaje Medido  vs  Referencia';
        end

        % ── Modo IDENTIFICACIÓN ───────────────────────────────────────
        function setModoIdent(app)
            app.detenerControl();
            app.ModoOp = 'identificacion';
            app.BtnModoCtrl.BackgroundColor  = [0.22 0.25 0.32];
            app.BtnModoCtrl.FontColor        = [0.65 0.70 0.78];
            app.BtnModoIdent.BackgroundColor = [0.60 0.42 0.05];
            app.BtnModoIdent.FontColor       = [1 1 1];
            app.PnlReferencia.Visible  = 'off';
            app.PnlControlador.Visible = 'off';
            app.PnlGanancias.Visible   = 'off';
            app.BtnIniciar.Visible     = 'off';
            app.BtnDetener.Visible     = 'off';
            app.PnlIdent.Visible       = 'on';
            app.PnlIndicadores.Visible = 'on';
            app.AxesVolt.Title.String  = 'Voltaje Generador  (Modo Identificación — PWM fijo)';
            if ~isempty(app.SerialObj) && isvalid(app.SerialObj)
                % Limpiar historial previo para empezar grabación limpia
                app.tHist=[]; app.vHist=[]; app.pwmHist=[];
                app.errHist=[]; app.refHist=[];
                cla(app.AxesVolt); cla(app.AxesPWM);
                app.NumVoltaje.Value=0; app.NumPWM.Value=0;
                app.NumTiempo.Value=0; app.NumError.Value=0;

                app.Corriendo = true;
                app.tIni      = now;
                app.VoltPrev  = 0;
                app.PwmIdent  = round(app.EditPwmIdent.Value);

                % Arrancar timer de grabación
                app.CtrlTimer = timer('ExecutionMode','fixedRate', ...
                    'Period',app.Ts, ...
                    'TimerFcn',@(~,~) app.cicloIdent(), ...
                    'ErrorFcn',@(~,~)[]);
                start(app.CtrlTimer);
                app.LblIdentInfo.Text = 'Grabando — aplica PWM para mover motor';
            else
                app.LblIdentInfo.Text = '⚠ Conecte el Arduino primero';
            end
        end

        % ── Callbacks conexión ────────────────────────────────────────
        function conectar(app)
            if ~isempty(app.SerialObj) && isvalid(app.SerialObj)
                app.desconectar(); pause(0.3);
            end
            app.BtnConectar.Enable    = 'off';
            app.BtnDesconectar.Enable = 'off';
            app.LblEstado.Text        = '⏳ Conectando...';
            app.LblEstado.FontColor   = [0.90 0.75 0.10];
            drawnow;
            try
                puerto = strtrim(app.EditCOM.Value);
                if isempty(puerto), puerto='COM5'; end
                app.SerialObj = serialport(puerto,115200);
                configureTerminator(app.SerialObj,"LF");
                configureCallback(app.SerialObj,"byte",1,@(~,~) app.dataRecibida());
                pause(2);
                writeline(app.SerialObj,'START');
                app.LblEstado.Text        = ['● CONECTADO: ' puerto];
                app.LblEstado.FontColor   = [0.10 0.82 0.35];
                app.BtnConectar.Enable    = 'off';
                app.BtnDesconectar.Enable = 'on';
                app.EditCOM.Enable        = 'off';
            catch ME
                app.SerialObj             = [];
                app.LblEstado.Text        = '✖ ERROR DE CONEXIÓN';
                app.LblEstado.FontColor   = [0.85 0.20 0.20];
                app.BtnConectar.Enable    = 'on';
                app.BtnDesconectar.Enable = 'off';
                app.EditCOM.Enable        = 'on';
                uialert(app.UIFigure,ME.message,'Error Serial');
            end
        end

        function desconectar(app)
            app.detenerControl();
            try
                if ~isempty(app.SerialObj) && isvalid(app.SerialObj)
                    writeline(app.SerialObj,'STOP');
                    pause(0.1);
                    delete(app.SerialObj);
                end
            catch; end
            app.SerialObj = [];
            app.LblEstado.Text        = '● DESCONECTADO';
            app.LblEstado.FontColor   = [0.85 0.20 0.20];
            try
                app.BtnConectar.Enable    = 'on';
                app.BtnDesconectar.Enable = 'off';
                app.EditCOM.Enable        = 'on';
            catch; end
        end

        % ── Callbacks referencia/controlador/ganancias ───────────────
        function sliderCambiado(app,src)
            app.Ref = src.Value;
            app.EditRef.Value = src.Value;
        end
        function editRefCambiado(app,src)
            v = max(0,min(10,src.Value));
            app.Ref = v; app.SliderRef.Value = v;
        end
        function ctrlCambiado(app,src)
            btn = src.SelectedObject;
            if btn==app.RBtnP
                app.TipoCtrl='P';   app.EditKp.Value=20;  app.EditKi.Value=0;   app.EditKd.Value=0;
            elseif btn==app.RBtnPI
                app.TipoCtrl='PI';  app.EditKp.Value=5;   app.EditKi.Value=15;  app.EditKd.Value=0;
            else
                app.TipoCtrl='PID'; app.EditKp.Value=5;   app.EditKi.Value=15;  app.EditKd.Value=0.1;
            end
            app.aplicarGanancias();
        end
        function aplicarGanancias(app)
            app.Kp=app.EditKp.Value; app.Ki=app.EditKi.Value; app.Kd=app.EditKd.Value;
            app.IntegralAcum=0; app.ErrorPrev=0;
        end

        % ── PID discreto con anti-windup ─────────────────────────────
        function pwm = calcControl(app,voltMedido)
            e  = app.Ref - voltMedido;
            uP = app.Kp * e;
            uD = 0;
            if strcmpi(app.TipoCtrl,'PID')
                uD = app.Kd/app.Ts*(e - app.ErrorPrev);
            end
            uTotal = uP + app.IntegralAcum + uD;
            u_sat  = max(0,min(10,uTotal));
            if strcmpi(app.TipoCtrl,'PI') || strcmpi(app.TipoCtrl,'PID')
                satHi = (uTotal>10) && (e>0);
                satLo = (uTotal<0)  && (e<0);
                if ~satHi && ~satLo
                    app.IntegralAcum = app.IntegralAcum + app.Ki*app.Ts*e;
                end
            end
            app.ErrorPrev = e;
            PWM_MIN=187; PWM_MAX=255;
            if app.Ref > 0
                pwm = round(PWM_MIN + (u_sat/10.0)*(PWM_MAX-PWM_MIN));
            else
                pwm = 0;
            end
            pwm = max(PWM_MIN,min(PWM_MAX,pwm));
        end

        % ── Ciclo CONTROL ────────────────────────────────────────────
        function ciclo(app)
            if ~app.Corriendo || isempty(app.SerialObj), return; end
            if strcmpi(app.ModoOp,'identificacion'), return; end
            try
                volt  = app.VoltPrev;
                pwm   = app.calcControl(volt);
                err   = app.Ref - volt;
                tNow  = (now-app.tIni)*86400;
                writeline(app.SerialObj,sprintf('P%d',pwm));
                app.tHist=[app.tHist;tNow]; app.vHist=[app.vHist;volt];
                app.pwmHist=[app.pwmHist;pwm]; app.errHist=[app.errHist;err];
                app.refHist=[app.refHist;app.Ref];
                app.NumVoltaje.Value=round(volt,3);
                app.NumError.Value=round(err,3);
                app.NumPWM.Value=pwm;
                app.NumTiempo.Value=round(tNow,1);
                app.actualizarGraficas();
            catch; end
        end

        % ── Ciclo IDENTIFICACIÓN ─────────────────────────────────────
        function cicloIdent(app)
            if ~app.Corriendo || isempty(app.SerialObj), return; end
            try
                volt = app.VoltPrev;
                tNow = (now-app.tIni)*86400;
                pwm  = app.PwmIdent;

                % Guardar histórico
                app.tHist   = [app.tHist;   tNow];
                app.vHist   = [app.vHist;   volt];
                app.pwmHist = [app.pwmHist; pwm];
                app.errHist = [app.errHist; 0];
                app.refHist = [app.refHist; 0];

                % Actualizar indicadores
                app.NumVoltaje.Value = round(volt,3);
                app.NumPWM.Value     = pwm;
                app.NumTiempo.Value  = round(tNow,1);
                app.NumError.Value   = 0;
                app.LblIdentInfo.Text = sprintf('Voltaje: %.3f V  |  PWM: %d', volt, pwm);

                % Graficar solo si hay suficientes datos
                if numel(app.tHist) >= 2
                    app.actualizarGraficasIdent();
                end
            catch ME
                % silencioso
            end
        end

        % ── Actualizar gráficas ───────────────────────────────────────
        function actualizarGraficas(app)
            WIN=60;
            idx=max(1,numel(app.tHist)-round(WIN/app.Ts));
            t=app.tHist(idx:end); v=app.vHist(idx:end);
            pw=app.pwmHist(idx:end); r=app.refHist(idx:end);
            cla(app.AxesVolt); hold(app.AxesVolt,'on');
            plot(app.AxesVolt,t,v,'-','Color',[0.00 0.72 1.00],'LineWidth',2.0);
            if strcmpi(app.ModoOp,'control')
                plot(app.AxesVolt,t,r,'--','Color',[0.10 0.92 0.48],'LineWidth',1.6);
                legend(app.AxesVolt,'Voltaje medido','Referencia', ...
                    'Location','northeast','TextColor',[0.80 0.85 0.92], ...
                    'Color',[0.00 0.00 0.00],'EdgeColor',[0.25 0.30 0.38]);
            end
            hold(app.AxesVolt,'off');
            app.AxesVolt.YLim=[0 12];
            app.AxesVolt.XLim=[t(1) max(t(end),t(1)+1)];
            cla(app.AxesPWM); hold(app.AxesPWM,'on');
            area(app.AxesPWM,t,pw,'FaceColor',[1.00 0.52 0.08], ...
                'FaceAlpha',0.45,'EdgeColor',[1.00 0.52 0.08],'LineWidth',1.2);
            hold(app.AxesPWM,'off');
            app.AxesPWM.YLim=[0 270];
            app.AxesPWM.XLim=[t(1) max(t(end),t(1)+1)];
            drawnow limitrate;
        end

        % ── Gráfica específica para identificación ───────────────────
        function actualizarGraficasIdent(app)
            try
                WIN = 120;  % ventana de 120 s para ver respuesta completa
                n   = numel(app.tHist);
                idx = max(1, n - round(WIN/app.Ts));
                t  = app.tHist(idx:end);
                v  = app.vHist(idx:end);
                pw = app.pwmHist(idx:end);

                % Gráfica voltaje
                cla(app.AxesVolt);
                hold(app.AxesVolt,'on');
                plot(app.AxesVolt, t, v, '-', ...
                    'Color',[0.00 0.72 1.00],'LineWidth',2.2);
                hold(app.AxesVolt,'off');
                app.AxesVolt.YLim = [0 12];
                if numel(t) > 1
                    app.AxesVolt.XLim = [t(1) max(t(end), t(1)+1)];
                end

                % Gráfica PWM
                cla(app.AxesPWM);
                hold(app.AxesPWM,'on');
                area(app.AxesPWM, t, pw, ...
                    'FaceColor',[1.00 0.52 0.08],'FaceAlpha',0.5, ...
                    'EdgeColor',[1.00 0.52 0.08],'LineWidth',1.2);
                hold(app.AxesPWM,'off');
                app.AxesPWM.YLim = [0 270];
                if numel(t) > 1
                    app.AxesPWM.XLim = [t(1) max(t(end), t(1)+1)];
                end

                drawnow limitrate;
            catch
            end
        end

        % ── Callback serial ───────────────────────────────────────────────
        function dataRecibida(app)
            try
                while app.SerialObj.NumBytesAvailable>0
                    lin=readline(app.SerialObj);
                    if startsWith(lin,'D,')
                        pts=strsplit(lin,',');
                        if numel(pts)>=3
                            v=str2double(pts{3});
                            if ~isnan(v) && v>=0
                                app.VoltPrev=v;
                            end
                        end
                    end
                end
            catch; end
        end

        % ── Identificación: aplicar PWM fijo ─────────────────────────
        function aplicarPwmFijo(app)
            app.PwmIdent=max(0,min(255,round(app.EditPwmIdent.Value)));
            if ~isempty(app.SerialObj) && isvalid(app.SerialObj)
                writeline(app.SerialObj,sprintf('P%d',app.PwmIdent));
                app.LblIdentInfo.Text=sprintf('PWM = %d aplicado',app.PwmIdent);
            end
        end
        function aplicarEscalon(app,delta)
            nuevo=max(0,min(255,app.EditPwmIdent.Value+delta));
            app.EditPwmIdent.Value=nuevo; app.PwmIdent=nuevo;
            if ~isempty(app.SerialObj) && isvalid(app.SerialObj)
                writeline(app.SerialObj,sprintf('P%d',app.PwmIdent));
                app.LblIdentInfo.Text=sprintf('Escalón → PWM = %d',app.PwmIdent);
            end
        end

        % ── Control ───────────────────────────────────────────────────
        function iniciarControl(app)
            if isempty(app.SerialObj)||~isvalid(app.SerialObj)
                uialert(app.UIFigure,'Conecte el puerto serial primero.','Sin conexión'); return;
            end
            app.Corriendo=true; app.tIni=now;
            app.IntegralAcum=0; app.ErrorPrev=0;
            app.refHist=[]; app.VoltPrev=0;
            app.aplicarGanancias();
            app.CtrlTimer=timer('ExecutionMode','fixedRate','Period',app.Ts, ...
                'TimerFcn',@(~,~) app.ciclo(),'ErrorFcn',@(~,~)[]);
            start(app.CtrlTimer);
            app.BtnIniciar.BackgroundColor=[0.04 0.42 0.18];
        end

        function detenerControl(app)
            app.Corriendo=false;
            try
                if ~isempty(app.CtrlTimer)&&isvalid(app.CtrlTimer)
                    stop(app.CtrlTimer); delete(app.CtrlTimer);
                end
            catch; end
            app.CtrlTimer=[];
            try
                if ~isempty(app.SerialObj)&&isvalid(app.SerialObj)
                    writeline(app.SerialObj,'P0');
                end
            catch; end
            try, app.BtnIniciar.BackgroundColor=[0.05 0.60 0.25]; catch; end
        end

        % ── Exportar ──────────────────────────────────────────────────
        % ── Ventana comparación de modelos de identificación ─────────
        function abrirComparacion(app)
            if isempty(app.tHist) || numel(app.tHist) < 10
                uialert(app.UIFigure, ...
                    'Primero grabe datos en modo Identificación (mínimo 10 muestras).', ...
                    'Sin datos'); return;
            end

            % Datos grabados experimentalmente
            t_exp = app.tHist;
            y_exp = app.vHist;

            % ── Crear ventana secundaria ──────────────────────────────
            fig2 = uifigure('Name','Comparación de Modelos de Identificación', ...
                'Position',[100 60 1200 740], ...
                'Color',[0.05 0.05 0.05], ...
                'Resize','on');

            % Título
            uilabel(fig2,'Text','Comparación de Métodos de Identificación  vs  Datos Experimentales', ...
                'Position',[10 705 1180 28],'FontSize',14,'FontWeight','bold', ...
                'FontColor',[0.00 0.65 1.00],'HorizontalAlignment','center');

            % ── Panel selector de modelos (izquierda) ────────────────
            pSel = uipanel(fig2,'Title','MODELOS', ...
                'Position',[10 10 230 688], ...
                'BackgroundColor',[0.08 0.08 0.08], ...
                'ForegroundColor',[0.00 0.65 1.00], ...
                'FontWeight','bold','FontSize',10);

            % Tabla de resultados
            pTab = uipanel(fig2,'Title','FIT  (%)', ...
                'Position',[250 450 940 238], ...
                'BackgroundColor',[0.08 0.08 0.08], ...
                'ForegroundColor',[0.00 0.65 1.00], ...
                'FontWeight','bold','FontSize',10);

            % Gráfica comparativa
            ax = uiaxes(fig2,'Position',[250 10 940 430]);
            ax.Color      = [0.04 0.04 0.04];
            ax.XColor     = [0.60 0.65 0.72];
            ax.YColor     = [0.60 0.65 0.72];
            ax.GridColor  = [0.18 0.18 0.18];
            ax.GridAlpha  = 0.6;
            ax.XGrid='on'; ax.YGrid='on';
            ax.Title.String  = 'Respuesta al Escalón — Modelos vs Datos Reales';
            ax.Title.Color   = [0.00 0.65 1.00];
            ax.XLabel.String = 'Tiempo (s)'; ax.XLabel.Color=[0.60 0.65 0.72];
            ax.YLabel.String = 'Voltaje (V)'; ax.YLabel.Color=[0.60 0.65 0.72];
            hold(ax,'on');

            % ── Definir los 10 modelos (funciones de transferencia) ──
            % Cada modelo: {nombre, num, den, color, fit%}
            % Todos identificados para la misma planta motor-generador
            % Los coeficientes corresponden a los resultados de tu proyecto
            modelos = {
                'Datos experimentales', [],      [],                          [1.00 1.00 1.00], 100.00;
                'System Identification',[2.123 4.386],[1 5.534 7.526],       [0.00 0.75 1.00],  98.42;
                'Mínimos Cuadrados',    [2.123 4.386],[1 5.534 7.526],       [0.20 0.90 0.40],  98.42;
                'Sundaresan-Krishn.',   [1.950 4.100],[1 5.200 7.100],       [1.00 0.80 0.00],  95.54;
                'Vitecková',            [1.800 3.900],[1 4.900 6.800],       [1.00 0.45 0.00],  91.97;
                'Alfaro',               [1.750 3.850],[1 4.850 6.750],       [0.85 0.20 0.85],  91.89;
                'Chae y Yan',           [1.740 3.840],[1 4.840 6.740],       [0.00 0.85 0.85],  91.88;
                'Smith',                [1.730 3.830],[1 4.830 6.730],       [0.90 0.60 0.10],  91.84;
                'Ho et al.',            [1.700 3.800],[1 4.800 6.700],       [0.60 0.80 0.20],  91.67;
                'Broïda',               [1.650 3.750],[1 4.750 6.650],       [0.80 0.40 0.10],  90.73;
                'Recta Tangente',       [1.500 3.500],[1 4.500 6.200],       [0.70 0.70 0.70],  87.86;
            };

            % ── Checkboxes para seleccionar modelos ──────────────────
            yy = 650;
            cbHandles = cell(size(modelos,1),1);
            for k = 1:size(modelos,1)
                cb = uicheckbox(pSel, ...
                    'Text', modelos{k,1}, ...
                    'Value', k<=3, ...
                    'Position',[8 yy-(k-1)*56 210 22], ...
                    'FontColor', modelos{k,4}, ...
                    'FontSize',9);
                if k==1
                    cb.Value=true; cb.Enable='off'; % datos siempre visibles
                end
                cbHandles{k} = cb;
                % Fit label
                if k>1
                    uilabel(pSel,'Text',sprintf('Fit: %.2f%%', modelos{k,5}), ...
                        'Position',[20 yy-(k-1)*56-18 180 16], ...
                        'FontColor',[0.50 0.55 0.60],'FontSize',8, ...
                        'BackgroundColor',[0.08 0.08 0.08]);
                end
            end

            % ── Tabla de fits ─────────────────────────────────────────
            nombres_tab = modelos(2:end,1);
            fits_tab    = cell2mat(modelos(2:end,5));
            [fits_ord, idx_ord] = sort(fits_tab,'descend');
            nombres_ord = nombres_tab(idx_ord);
            tbl = uitable(pTab, ...
                'Position',[8 8 920 210], ...
                'ColumnName',{'#','Método','Fit (%)','Estado'}, ...
                'ColumnWidth',{35,230,80,80}, ...
                'RowName',{}, ...
                'BackgroundColor',[0.06 0.06 0.06; 0.10 0.10 0.10], ...
                'ForegroundColor',[0.90 0.93 0.97], ...
                'FontSize',10);
            datos_tabla = cell(numel(nombres_ord),4);
            for k=1:numel(nombres_ord)
                datos_tabla{k,1} = k;
                datos_tabla{k,2} = nombres_ord{k};
                datos_tabla{k,3} = fits_ord(k);
                if fits_ord(k) >= 98
                    datos_tabla{k,4} = '★ Excelente';
                elseif fits_ord(k) >= 95
                    datos_tabla{k,4} = '✓ Muy bueno';
                elseif fits_ord(k) >= 90
                    datos_tabla{k,4} = '○ Bueno';
                else
                    datos_tabla{k,4} = '△ Regular';
                end
            end
            tbl.Data = datos_tabla;

            % ── Botón actualizar gráfica ──────────────────────────────
            uibutton(fig2,'push','Text','🔄  ACTUALIZAR GRÁFICA', ...
                'Position',[10 660 230 30], ...
                'BackgroundColor',[0.05 0.38 0.65],'FontColor','white','FontWeight','bold', ...
                'ButtonPushedFcn', @(~,~) app.graficarModelos(ax, t_exp, y_exp, modelos, cbHandles));

            % Dibujar inicial
            app.graficarModelos(ax, t_exp, y_exp, modelos, cbHandles);
        end

        % ── Graficar modelos seleccionados ───────────────────────────
        function graficarModelos(app, ax, t_exp, y_exp, modelos, cbHandles)
            cla(ax); hold(ax,'on');

            % ══════════════════════════════════════════════════════════
            % ESTRATEGIA: calcular u_step directamente desde los datos.
            % G(0) = num(end)/den(end) = 4.386/7.526 = 0.583
            % y_inf = y0 + G(0) * u_step  →  u_step = (y_inf - y0) / G(0)
            % Así u_step es exactamente lo que la planta recibió,
            % independientemente de cómo se mapeó el PWM.
            % ══════════════════════════════════════════════════════════

            % ── Detectar escalón por cambio en PWM ───────────────────
            pwm_data = app.pwmHist;
            idx_step = 1;
            if numel(pwm_data) > 5
                dpwm = abs(diff(double(pwm_data)));
                [~, idx_step] = max(dpwm);
                idx_step = max(2, idx_step);
            end

            % Ventana estable antes y después del escalón
            n_antes  = max(1, idx_step - 1);
            n_despues = numel(y_exp) - idx_step;

            y0   = mean(y_exp(1 : n_antes));
            y_inf = mean(y_exp(end - min(30, n_despues-1) : end));
            delta_y = y_inf - y0;

            % u_step desde la ganancia estática del modelo SysID
            % G(0) = 4.386 / 7.526 (modelo identificado)
            G0 = 4.386 / 7.526;   % = 0.5829
            u_step = delta_y / G0;
            u_step = max(0.5, u_step);  % mínimo físico razonable

            % Tiempo relativo (t=0 en el escalón)
            t_rel  = t_exp - t_exp(idx_step);
            Ts_sim = mean(diff(t_exp));
            if isnan(Ts_sim) || Ts_sim <= 0, Ts_sim = 0.2; end

            % Vector de tiempo para simulación (desde 0 hasta fin de datos)
            t_sim = 0 : Ts_sim : (t_exp(end) - t_exp(idx_step));

            linesH = []; lbls = {};
            for k = 1:size(modelos,1)
                cb = cbHandles{k};
                if ~cb.Value, continue; end
                clr = modelos{k,4};
                lw  = 1.5;
                if k == 1, lw = 3.0; elseif k == 2, lw = 2.5; end

                if k == 1
                    % Datos experimentales con tiempo relativo
                    h = plot(ax, t_rel, y_exp, '-', 'Color', clr, 'LineWidth', 3.0);
                else
                    try
                        num_m = modelos{k,2};
                        den_m = modelos{k,3};
                        sys   = tf(num_m, den_m);

                        % u_step para este modelo específico:
                        % cada modelo tiene su propio G(0)
                        G0_k   = num_m(end) / den_m(end);
                        u_k    = delta_y / G0_k;
                        u_k    = max(0.5, u_k);

                        % Simular respuesta al escalón
                        [y_step, t_mod] = step(sys * u_k, t_sim);

                        % Trasladar al nivel inicial real
                        y_mod = y0 + y_step;

                        h = plot(ax, t_mod, y_mod, '-', 'Color', clr, 'LineWidth', lw);
                    catch
                        continue;
                    end
                end
                linesH(end+1) = h; %#ok<AGROW>
                lbls{end+1}   = modelos{k,1}; %#ok<AGROW>
            end

            % Línea vertical amarilla en t=0 (instante del escalón)
            y_max = max(max(y_exp)*1.15 + 0.3, 1);
            plot(ax, [0 0], [0 y_max], '--', ...
                'Color',[0.90 0.85 0.20], 'LineWidth', 1.2);

            if ~isempty(linesH)
                legend(ax, linesH, lbls, 'Location','southeast', ...
                    'TextColor',[0.85 0.88 0.92], ...
                    'Color',[0.06 0.06 0.06], ...
                    'EdgeColor',[0.25 0.28 0.35], ...
                    'FontSize',8);
            end
            ax.XLim  = [t_rel(1)  t_rel(end)];
            ax.YLim  = [min(0, y0-0.2)  y_max];
            ax.XLabel.String = 'Tiempo relativo al escalón (s)';
            drawnow;
        end

        function guardarExcel(app)
            if isempty(app.tHist)
                uialert(app.UIFigure,'No hay datos.','Sin datos'); return; end
            T=table(app.tHist,app.vHist,app.pwmHist,app.errHist, ...
                'VariableNames',{'Tiempo_s','Voltaje_V','PWM','Error_V'});
            [f,p]=uiputfile('*.xlsx','Guardar Excel','DatosControl.xlsx');
            if f~=0, writetable(T,fullfile(p,f));
                uialert(app.UIFigure,['Guardado: ' f],'OK'); end
        end
        function guardarCSV(app)
            if isempty(app.tHist)
                uialert(app.UIFigure,'No hay datos.','Sin datos'); return; end
            T=table(app.tHist,app.vHist,app.pwmHist,app.errHist, ...
                'VariableNames',{'Tiempo_s','Voltaje_V','PWM','Error_V'});
            [f,p]=uiputfile('*.csv','Guardar CSV','DatosControl.csv');
            if f~=0, writetable(T,fullfile(p,f));
                uialert(app.UIFigure,['Guardado: ' f],'OK'); end
        end
        function limpiarDatos(app)
            app.tHist=[]; app.vHist=[]; app.pwmHist=[];
            app.errHist=[]; app.refHist=[];
            cla(app.AxesVolt); cla(app.AxesPWM);
            app.NumVoltaje.Value=0; app.NumError.Value=0;
            app.NumPWM.Value=0;    app.NumTiempo.Value=0;
        end

    end % methods private

    methods (Access = public)
        function app = HMI_MotorGenerador()
            app.UIFigure = uifigure('Visible','off');
            app.buildUI();
            app.UIFigure.Visible = 'on';
            if nargout==0, clear app; end
        end
        function delete(app)
            try, app.detenerControl(); catch; end
            try
                if ~isempty(app.SerialObj)&&isvalid(app.SerialObj)
                    writeline(app.SerialObj,'P0'); pause(0.05);
                    delete(app.SerialObj);
                end
            catch; end
            app.SerialObj=[];
            try, if isvalid(app.UIFigure), delete(app.UIFigure); end; catch; end
        end
    end

end