matlab
%% Extraer tiempo y salida

t = IDENTIFICACION(:,1);
y = IDENTIFICACION(:,2);

%% Eliminar el segundo dato (dos ceros consecutivos)

t(2) = [];
y(2) = [];

%% Tiempo de muestreo

Ts = mean(diff(t));

%% Entrada escalón de 8 V

N = length(y);

u = [zeros(10,1);
     8*ones(N-10,1)];

%% Crear objeto de identificación

data = iddata(y,u,Ts);

%% Identificación mediante función de transferencia

modelo1 = tfest(data,1);     % 1 polo
modelo2 = tfest(data,2);     % 2 polos
modelo3 = tfest(data,3);     % 3 polos

%% Comparación

figure
compare(data,modelo1,modelo2,modelo3)
grid on

%% Mostrar funciones de transferencia

disp('MODELO DE 1 POLO')
G1 = tf(modelo1)

disp('MODELO DE 2 POLOS')
G2 = tf(modelo2)

disp('MODELO DE 3 POLOS')
G3 = tf(modelo3)

%% Extraer tiempo y salida

t = IDENTIFICACION(:,1);
y = IDENTIFICACION(:,2);

%% Eliminar el segundo dato (dos ceros consecutivos)

t(2) = [];
y(2) = [];

%% Ganancia del sistema (escalón de 8 V)

K = (y(end)-y(1))/8;

%% Derivada de la respuesta

dy = gradient(y,t);

%% Punto de máxima pendiente

[pend_max,indice] = max(dy);

t_inf = t(indice);
y_inf = y(indice);

%% Método de la recta tangente

L = t_inf - y_inf/pend_max;

T = (y(end)-y_inf)/pend_max;

%% Mostrar resultados

fprintf('K = %.6f\n',K)
fprintf('L = %.6f s\n',L)
fprintf('T = %.6f s\n',T)