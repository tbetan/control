function PIDFINAL

clc
close all

%% PARAMETROS PID

Kp = 2.54;
Ki = 16.1;
Kd = 0.05;

PWM_BASE = 170;
Ts = 0.02;

%% COMUNICACION

s = serialport("COM5",115200);

pause(3)

%% VARIABLES

integral = 0;
error_anterior = 0;
runControl = false;

%% VENTANA

fig = uifigure;
fig.Position = [100 100 1000 600];
fig.Name = 'CONTROL PID EN TIEMPO REAL';

%% REFERENCIA

uilabel(fig,...
    'Position',[20 540 120 22],...
    'Text','Referencia (V)');

refBox = uieditfield(fig,'numeric');
refBox.Position = [20 510 120 30];
refBox.Value = 8;

%% VOLTAJE

lblVolt = uilabel(fig);
lblVolt.Position = [20 450 250 30];
lblVolt.Text = 'Voltaje: 0 V';

%% PWM

lblPWM = uilabel(fig);
lblPWM.Position = [20 410 250 30];
lblPWM.Text = 'PWM: 0';

%% BOTON INICIAR

btnStart = uibutton(fig,'push');
btnStart.Position = [20 340 120 40];
btnStart.Text = 'INICIAR';

%% BOTON DETENER

btnStop = uibutton(fig,'push');
btnStop.Position = [20 280 120 40];
btnStop.Text = 'DETENER';

%% GRAFICA

ax = uiaxes(fig);
ax.Position = [250 80 700 500];

title(ax,'Voltaje en Tiempo Real')
xlabel(ax,'Tiempo (s)')
ylabel(ax,'Voltaje (V)')
grid(ax,'on')

hold(ax,'on')

%% LINEAS

hVolt = animatedline(ax,...
    'Color','b',...
    'LineWidth',2);

hRef = animatedline(ax,...
    'Color','r',...
    'LineStyle','--',...
    'LineWidth',2);

%% CALLBACKS

btnStart.ButtonPushedFcn = @iniciar;
btnStop.ButtonPushedFcn = @detener;

%% FUNCION INICIAR

    function iniciar(~,~)

        runControl = true;

        clearpoints(hVolt);
        clearpoints(hRef);

        integral = 0;
        error_anterior = 0;

        tiempoInicio = tic;

        while runControl

            drawnow

            if ~isvalid(fig)
                break
            end

            Vref = refBox.Value;

            try
                voltaje = str2double(readline(s));
            catch
                continue
            end

            error = Vref - voltaje;

            integral = integral + error*Ts;

            derivada = (error-error_anterior)/Ts;

            salidaPID = ...
                Kp*error + ...
                Ki*integral + ...
                Kd*derivada;

            pwm = round(PWM_BASE + salidaPID);

            pwm = max(0,min(255,pwm));

            writeline(s,num2str(pwm));

            t = toc(tiempoInicio);

            addpoints(hVolt,t,voltaje);
            addpoints(hRef,t,Vref);

            lblVolt.Text = sprintf('Voltaje: %.2f V',voltaje);

            lblPWM.Text = sprintf('PWM: %d',pwm);

            error_anterior = error;

            drawnow limitrate

        end

    end

%% FUNCION DETENER

    function detener(~,~)

        runControl = false;

        writeline(s,'170');

    end

end