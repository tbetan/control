t = IDENTIFICACION(:,1);
y = IDENTIFICACION(:,2);

t(2) = [];
y(2) = [];

Ts = mean(diff(t));

u = [zeros(10,1);
     8*ones(length(y)-10,1)];

data = iddata(y,u,Ts);